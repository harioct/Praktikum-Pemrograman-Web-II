<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Rute default menuju halaman login
$routes->get('/', 'LoginController::index');

// Rute untuk login
$routes->get('/login', 'LoginController::index');
$routes->post('/login', 'LoginController::login');

// Rute untuk register
$routes->get('/register', 'RegisterController::index');
$routes->post('/register', 'RegisterController::store');

// Rute untuk logout
$routes->get('/logout', 'LoginController::logout');

// Rute untuk dashboard dengan filter autentikasi
$routes->get('/dashboard', 'Dashboard::index', ['filter' => 'auth']);

// Grup rute untuk buku dengan filter autentikasi
$routes->group('books', ['filter' => 'auth'], function($routes) {
    $routes->get('/', 'BookController::index');
    $routes->get('create', 'BookController::create');
    $routes->post('store', 'BookController::store');
    $routes->get('edit/(:segment)', 'BookController::edit/$1');
    $routes->post('update/(:segment)', 'BookController::update/$1');
    $routes->get('delete/(:segment)', 'BookController::delete/$1');
});